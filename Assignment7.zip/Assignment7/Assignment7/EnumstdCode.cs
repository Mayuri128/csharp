﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment7
{
    class EnumstdCode
    {
        static void Main()
        {
            Console.WriteLine("city Name");
            foreach (string name in Enum.GetNames(typeof(stdcode)))
            {
                Console.WriteLine(name);
            }
            Console.WriteLine("city Codes");
            foreach (int code in Enum.GetValues(typeof(stdcode)))
            {
                Console.WriteLine(code);
            }
            Console.ReadLine();
        }
    }
}
