﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment7
{
    class StdCodeAndCity
    {
    }
    enum stdcode
    {
        pune=12,Mumbai=21,Delhi=78,USA=02,UK=01
    }
}
