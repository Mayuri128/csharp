﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment7
{
    class Program
    {
    }
        struct student
        {
            int rollno;
            string name;
            string gender;
            string mobileno;
            public student(int rollno,string name,string gender,string mobileno)
            {
                this.rollno = rollno;
                this.name = name;
                this.gender = gender;
                this.mobileno = mobileno;
            }
            public string Display(int rollno, string name, string gender, string mobileno)
            {
                return string.Format("rollno={0} name={1} gender={2} marks={3}", rollno, name, gender, mobileno);
            }
        }
    }

