﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment8
{
    /// <summary>
    /// create a avstract class Computer having Following Functiuon
    /// 1.BootUp();
    /// 2.shutDown();
    /// </summary>
    public abstract class Computer
    {
        public string BootUp()
        {
            return "This is BootUp function";
        }
        public string ShutDown()
        {
            return "This is ShutDown function";
        }
    }
    public class DerivedComputer : Computer
    {
        static void Main()
        {
            DerivedComputer dc = new DerivedComputer();
            Console.WriteLine(dc.BootUp());
            Console.WriteLine(dc.ShutDown());
            Console.ReadLine();
        }
        
    }
}

