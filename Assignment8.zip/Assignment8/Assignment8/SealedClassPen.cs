﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment8
{
    /// <summary>
    /// create a sealed classes pen and following function in it;
    /// 1.startWriting()
    /// 2.stopWriting()
    /// </summary>
    class SealedClassPen
    {
        public string StartWriting()
        {
            return "*******This is Start Writing*********";
        }
        public string StopWriting()
        {
            return "****This is Stop Writing******";
        }
    }
    public class Sealed_MainMethod
    {
        static void Main()
        {
            SealedClassPen Sealed = new SealedClassPen();
            Console.WriteLine(Sealed.StartWriting());
            Console.WriteLine(Sealed.StopWriting());
            Console.ReadLine();
        }
    }

}

