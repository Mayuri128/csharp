﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment8
{
    /// <summary>
    /// The Requirement of any application  is asking the user to register.
    /// and there should not be two user accounts with same Email ID;
    /// </summary>
    class FormRquirement
    {
        long id;
        string name;
        string email_id;
        string date_of_Birth;

        public FormRquirement()
        {
            Console.WriteLine("This is Default Constructor of Requirements");

        }
        public FormRquirement(long id, string name, string email_id, string date_of_Birth)
        {
            this.id = id;
            this.email_id = email_id;
            this.name = name;
            this.date_of_Birth = date_of_Birth;
        }
        public override string ToString()
        {
            return string.Format("Id={0}\nName={1}\nEmailId={2}\nDate of Birth={3}\n", id, name, email_id, date_of_Birth);
        }
        public static bool IsEmailDuplicate(List<FormRquirement> forms, string mail)
        {
            foreach (var temp in forms)
            {
                if (temp.email_id == mail)
                {
                    return true;
                }
            }
            return false;
        }

        static void Main()
        {

            List<FormRquirement> mylist = new List<FormRquirement>();
            int choice;
            do
            {

                Console.WriteLine("Enter User Id");
                long id = Convert.ToInt64(Console.ReadLine());


                Console.WriteLine("Enter User Name");
                string name = Console.ReadLine();
                Console.WriteLine("Enter User Email_id");
                string email_id = Console.ReadLine();
                bool result = IsEmailDuplicate(mylist, email_id);
                while (result)
                {
                    Console.WriteLine("Email Id not available");
                    email_id = Console.ReadLine();
                    result = IsEmailDuplicate(mylist, email_id);
                }
                Console.WriteLine("Enter Date of Birth");
                string _dateofBirth = Console.ReadLine();

                FormRquirement item = new FormRquirement(id, name, email_id, _dateofBirth);
                Console.WriteLine("User Details");

                Console.Write(item.ToString());// Overriden ToString Method

                Console.WriteLine("Do you want to add more users");
                Console.WriteLine("1.Add\n2.Exit");

                choice = Convert.ToInt32(Console.ReadLine());

                mylist.Add(item);

            } while (choice != 2);

            Console.ReadLine();
        }

    }
}
