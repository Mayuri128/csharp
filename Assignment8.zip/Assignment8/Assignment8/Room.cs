﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment8
{
    /// <summary>
    /// create a simple application in which user can store details of the hotel
    /// and rooms available in it
    /// </summary>
    class Room
    {  
        int number;
        int floor;
        string  type;
        int capacity;
        DateTime bookedtime;
        double price;


        public Room()
        {
            Console.WriteLine("This is the Default Constructor Room");
        }
        public Room(int number, int floor, string type, int capacity, DateTime bookedtime, double price)
        {
            this.number = number;
            this.floor = floor;
            this.type = type;
            this.price = price;
            this.capacity = capacity;
            this.bookedtime = bookedtime;

        }
        public override string ToString()
        {
            return string.Format("Number={0}\n Floor={1}\n Type={2}\n Capacity={3}\n Booked Time={4}\n Price={5}\n", number, floor, type, capacity, bookedtime, price);
        }
    }
    class HotelRoomProperties
    {
        private int number;
        public int _number
        {
            get
            {
                return number;
            }
            set
            {
                number = value;
            }
        }
        public int _floor { get; set; }
        public string _type { get; set; }
        public DateTime _bookedtime { get; set; }
        public int _capacity { get; set; }
        public double _price { get; set; }
    }
    class HotelRoom_MainMethod
    {
        static void Main()
        {

            Console.WriteLine("Enter Your Room No");
            int no = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter which Room type you want (Ac/Non-AC)");
            string type = Console.ReadLine();

            Console.WriteLine("Enter Checked IN Time(hh:mm:ss)");
            DateTime time = Convert.ToDateTime(Console.ReadLine());

            Console.WriteLine("Enter Room Capacity");
            int capacity = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter Floor (1-5)");
            int floor = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter Room Price");
            double price = Convert.ToDouble(Console.ReadLine());

            Room room = new Room(no, floor, type, capacity, time, price);
            Console.Write(room.ToString());

            Console.ReadLine();

        }
    }
}